from ast import In
import os
import fileinput
from datetime import datetime

def menuDisplay():
    print("++++++++++=======================================++++++++++")
    print("\t \t \t Inventory Management System ")
    print("++++++++++=======================================++++++++++")
    print("\t 1. Manage Suppiler  \t\t 2. Manage Inventory")
    print("\t 3. Manage Hospital Supply \t\t 4. Quit")
    C = int(input("Enter Your Choice:- "))
    menuSelection(C)

def menuSelection(C):
    if C ==1:
        managerInv()
    elif C ==2:
        Inv()
    elif C ==3:
        managehospital()
    elif C ==4:
        exit()
# -------------------------SUPPILER SECTION -----------------
def managerInv():
    print("++++++++++=======================================++++++++++")
    print("\t \t \t Welcome to manager pannel ")
    print("++++++++++=======================================++++++++++")
    print("\t 1. Add Suppiler  \t\t 2. Delete Suppiler")
    print("\t 3. View Suppiler \t\t 4. EXIT")
    C = int(input("Enter Your Choice:- "))
    if C ==1:
        addmanager()
    elif C ==2:
        Deletesuppile()
    elif C ==3:
        viewsuppiler()
    elif C ==4:
        exit()
    
def addmanager():
    InventoryFile = open('Suppiler.txt', 'a')
    print("\n\n ++++++  Adding Suppiler +++++")
    print("===================================")
    suppiler_nmae = input("Enter the name of the Suppiler: ")
    suppiler_code = input("Enter the Code of the Suppiler: ")
    suppiler_phone = input("Enter The suppiler phone number :")

    InventoryFile.write(suppiler_nmae + '\n')
    InventoryFile.write(suppiler_code + '\n')
    InventoryFile.write(suppiler_phone + '\n')
    InventoryFile.close()
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            managerInv()
    else:
        exit()
    
def Deletesuppile():
    print("\n\n ++++++  DELETE Suppiler +++++")
    print("===================================")
    item_description = input("Enter the Suppiler name to remove from inventory: ")

    file = fileinput.input('Suppiler.txt', inplace=True)

    for line in file:
         if item_description in line:
             for i in range(1):
                 next(file, None)
         else:
             print(line.strip('\n'), end='\n')
    item_description
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()

def viewsuppiler():
    InventoryFile = open('Suppiler.txt', 'r')
    item_description = InventoryFile.readline()
    print("\n\n ++++++  VIEW Suppiler +++++")
    print("===================================")
    while item_description != '':
        item_quantity = InventoryFile.readline()
        item_quantity1 = InventoryFile.readline()
        item_description = item_description.rstrip('\n')
        item_quantity = item_quantity.rstrip('\n')
        item_quantity1 = item_quantity1.rstrip('\n')
        print('SUPPILER NAME :-     ', item_description)
        print('SUPPILER CODE:- ', item_quantity)
        print('SUPPILER MOBILE :- ', item_quantity1)
        print('------------------')
        item_description = InventoryFile.readline()
    InventoryFile.close()
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()

#-------------------------INVENTARY ---------------------
def Inv():
    print("++++++++++=======================================++++++++++")
    print("\t \t \t Welcome to INVENTORY pannel ")
    print("++++++++++=======================================++++++++++")
    print("\t 1. Add Item  \t\t 2. Remove Item")
    print("\t 3. Update Item \t\t 4. Search Item")
    print("\t 5. Print Item \t\t 6. Quot")
    CHOICE = int(input("Enter Your Choice:- "))
    if CHOICE == 1:
        addInventory()
    elif CHOICE == 2:
        removeInventory()
    elif CHOICE == 3:
        updateInventory()
    elif CHOICE == 4:
         searchInventory()
    elif CHOICE == 5:
        printInventory()
    elif CHOICE == 99:
        exit()
#------- Adding item to inventory --------------
def addInventory():
    InventoryFile = open('ppe.txt', 'a')
    print("+++++    Adding Item ++++++")
    print("\n============================")
    print("\n \t\t ITEM CODE   \t ITEM NAME ")
    print(" \t\t  HC \t\t Head Cover")
    print(" \t\t  FS \t\t Face Shield")
    print(" \t\t  MS \t\t Mask")
    print(" \t\t  GL \t\t Gloves")
    print(" \t\t  GW \t\t Gown")
    print(" \t\t  SC \t\t Shoe Covers")
    item_description = input("Enter the name of the item :- ")
    item_code = input("Enter the Item code :- ")
    item_quantity = input("Enter the quantity(in BOXES) of the item: ")
    suppiler_code = input("Enter the suppiler code :- ")
    InventoryFile.write(item_description + '\n')
    InventoryFile.write(item_code + "\n")
    InventoryFile.write(item_quantity + '\n')
    InventoryFile.write(suppiler_code+'\n')
    InventoryFile.close()
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()

def removeInventory():
    print("+++++    Removing Item ++++++")
    print("============================")
    item_description = input("Enter the item name to remove from inventory: ")

    file = fileinput.input('ppe.txt', inplace=True)

    for line in file:
         if item_description in line:
             for i in range(3):
                 next(file, None)
         else:
             print(line.strip('\n'), end='\n')
    item_description
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()

def updateInventory():
    print("Updating Inventory")
    print("==================")
    item_description = input('Enter the item to update: ')
    item_quantity = int(input("Enter the updated quantity. Enter - for less: "))

    with open('ppe.txt', 'r') as f:
        filedata = f.readlines()

    replace = ""
    line_number = 0
    count = 0
    f = open('ppe.txt','r')
    file = f.read().split('\n')
    for i, line in enumerate(file):
        if item_description in line:
            for b in file[i+2:i+3]:
                value = int(b)
                print(value)
                change = value + (item_quantity)
                replace = b.replace(b, str(change))
                line_number = count
            count = i + 2      
    f.close()
    
    filedata[count] = replace + '\n'

    with open('ppe.txt', 'w') as f:
        for line in filedata:
            f.write(line)
                                            
                
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()


def searchInventory():
    print('Searching Inventory')
    print('===================')
    item_description = input('Enter the name of the item: ')
    
    f = open('ppe.txt', 'r')
    search = f.readlines()
    f.close
    for i, line in enumerate(search):
        if item_description in line:
            for b in search[i:i+1]:
                print('Item:     ', b, end='')
            for c in search[i+1:i+2]:
                print('Iteam Code: ', c, end='')
            for d in search[i+2:i+3]:
                print('Quantity:     ', d, end='')
                print('----------')
        
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()
def printInventory():
    InventoryFile = open('ppe.txt', 'r')
    item_description = InventoryFile.readline()
    print('Current Inventory')
    print('-----------------')
    print("Item:\t\tIteam code\t\tIteam Quantity\t\tSuppiler Code")
    while item_description != '':
        iteam_code = InventoryFile.readline()
        item_quantity = InventoryFile.readline()
        suppiler_code  = InventoryFile.readline()
        item_description = item_description.rstrip('\n')
        iteam_code = iteam_code.rstrip('\n')
        item_quantity = item_quantity.rstrip('\n')
        suppiler_code = suppiler_code.rstrip('\n')
        print(item_description,"\t\t",iteam_code,"\t\t\t",item_quantity,"\t\t\t",suppiler_code)
        print('-------------------------------------------------------------------------------------------------------')
        item_description = InventoryFile.readline()
    InventoryFile.close()

    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else:
        exit()
# -------------------------------- Hospital management  --------------

def managehospital():
    print("++++++++++=======================================++++++++++")
    print("\t \t \t Welcome to Hospital Distribution pannel ")
    print("++++++++++=======================================++++++++++")
    print("\t 1. Add hospital  \t\t 2. Delete hospital")
    print("\t 3. View Hospital \t\t 4. Distribute inventory to Hospital")
    print("\t 5. Quit")
    C = int(input("Enter Your Choice:- "))
    if C ==1:
        Add_hospital()
    elif C ==2:
        Deletesuppile()
    elif C ==3:
        viewhospital()
    elif C == 4:
        distribution_hospital()
    elif C ==5:
        exit()
#---------------Adding Hospital ------------
def Add_hospital():
    InventoryFile = open('hospital.txt', 'a')
    print("\n\n ++++++  Adding Hospital +++++")
    print("===================================")
    hos_nmae = input("Enter the name of the Hospital: ")
    hos_add = input("Enter Hospital Address: ")
    hos_phone = input("Enter The Hospital phone number :")

    InventoryFile.write(hos_nmae + '\n')
    InventoryFile.write(hos_add + '\n')
    InventoryFile.write(hos_phone + '\n')
    InventoryFile.close()
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            managehospital()
    else:
        exit()
#----------------- View Hospital--------------------
def viewhospital():
    InventoryFile = open('hospital.txt', 'r')
    item_description = InventoryFile.readline()
    print("\n\n ++++++  VIEW Hospital +++++")
    print("===================================")
    print("\nHospital nme \t\t   Hospita Address \t\t\t Hospital Phone")
    while item_description != '':
        item_quantity = InventoryFile.readline()
        item_quantity1 = InventoryFile.readline()
        item_description = item_description.rstrip('\n')
        item_quantity = item_quantity.rstrip('\n')
        item_quantity1 = item_quantity1.rstrip('\n')
        print(item_description,"\t\t    ",item_quantity,"\t\t\t\t",item_quantity1)
        print('----------------------------------------------------------------')
        item_description = InventoryFile.readline()
    InventoryFile.close()
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            managehospital()
    else:
        exit()
def distribution_hospital():
    InventoryFile = open('distribution.txt', 'a')
    print("\n\n ++++++  Distrubutung  Hospital +++++")
    print("===================================")
    now = str(datetime.now())
    hos_nmae = input("Enter the name of the Hospital: ")
    hos_add = input("Enter Hospital Address: ")
    hos_phone = input("Enter The Hospital phone number :")
    File = open('ppe.txt', 'r')
    item_description = File.readline()
    print('Current Inventory')
    print('-----------------')
    print("Item:\t\tIteam code\t\tIteam Quantity\t\tSuppiler Code")
    while item_description != '':
        iteam_code = File.readline()
        item_quantity = File.readline()
        suppiler_code  = File.readline()
        item_description = item_description.rstrip('\n')
        iteam_code = iteam_code.rstrip('\n')
        item_quantity = item_quantity.rstrip('\n')
        suppiler_code = suppiler_code.rstrip('\n')
        print(item_description,"\t\t",iteam_code,"\t\t\t",item_quantity,"\t\t\t",suppiler_code)
        print('-------------------------------------------------------------------------------------------------------')
        item_description = File.readline()
    File.close()
    iteam_code = input("Enter the item code want to supply :- ")
    iiteam_quantity = input("Enter the Quantity to be distributed :- ")

    InventoryFile.write(now +'\n')
    InventoryFile.write(hos_nmae + '\n')
    InventoryFile.write(hos_add + '\n')
    InventoryFile.write(hos_phone + '\n')
    InventoryFile.write(iteam_code + '\n')
    InventoryFile.write(iiteam_quantity +'\n')
    InventoryFile.close()
    #------------------- now updating to ppe.txt --------
    with open('ppe.txt', 'r') as f:
        filedata = f.readlines()

    replace = ""
    line_number = 0
    count = 0
    f = open('ppe.txt','r')
    file = f.read().split('\n')
    for i, line in enumerate(file):
        if item_description in line:
            for b in file[i+2:i+3]:
                value = int(b)
                print(value)
                change = value - int(item_quantity)
                replace = b.replace(b, str(change))
                line_number = count
            count = i + 2      
    f.close()
    
    filedata[count] = replace + '\n'

    with open('ppe.txt', 'w') as f:
        for line in filedata:
            f.write(line)
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            managehospital()
    else:
        exit()

menuDisplay()